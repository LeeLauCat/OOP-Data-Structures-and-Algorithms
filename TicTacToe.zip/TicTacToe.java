
package tictactoe;
import java.util.*;


public class TicTacToe {

   public static final int EMPTY = 0,CROSS = 1,NOUGHT = 2;
   public static final String EXIT="X";
   // Name-constants to represent the various states of the game
   public static final int PLAYING = 0,DRAW = 1,CROSS_WON = 2,NOUGHT_WON = 3; 
   // The game board and the game status
   public static final int ROWS = 3, COLS = 3; // number of rows and columns
   public static int[][] board = new int[ROWS][COLS]; // game board in 2D array
                                                      //  containing (EMPTY, CROSS, NOUGHT)
   public static int currentState;  // the current state of the game
                                    // (PLAYING, DRAW, CROSS_WON, NOUGHT_WON)
   public static int currentPlayer; // the current player (CROSS or NOUGHT)
   public static int currntRow, currentCol; 
   public static String player1,player2;
   public static int choice;
   public static int second,minute,hour,day,month,year;// date and time
   
    public static Scanner in=new Scanner(System.in);
    public static void main(String[] args) {    

        System.out.println("WELCOME TO THE X AND O GAME");
        System.out.println("******************************************************");
        System.out.print("enter (1) to play the game or (2) to view the game history >>");
        choice=in.nextInt();
        if(choice==1){
            playerInput();            
        }
    else if(choice==2){ 
        history();
            
        }                
    }
   /** Initialize the game-board contents and the current states */
   public static void initGame() {
      for (int row = 0; row < ROWS; ++row) {
         for (int col = 0; col < COLS; ++col) {
            board[row][col] = EMPTY;  // all cells empty
         }
      }
      currentState = PLAYING; // ready to play
      currentPlayer = CROSS;  // cross plays first
   } 
   /** Player with the "theSeed" makes one move, with input validation.
       Update global variables "currentRow" and "currentCol". */
   public static void playerMove(int theSeed) {
      boolean validInput = false;  // for input validation      
      do {          
         if (theSeed == CROSS) {
            System.out.print(player1+" enter row number (row[1-3] >>column[1-3]): ");
         } else {
            System.out.print(player2+" enter your move (row[1-3] column[1-3]): ");
         }
         int row = in.nextInt() - 1;  // array index starts at 0 instead of 1
         int col = in.nextInt() - 1;
         if (row >= 0 && row < ROWS && col >= 0 && col < COLS && board[row][col] == EMPTY) {
            currntRow = row;
            currentCol = col;
            board[currntRow][currentCol] = theSeed;  // update game-board content
            validInput = true;  // input okay, exit loop
         } else {
            System.out.println("This move at (" + (row + 1) + "," + (col + 1)
                  + ") is not valid. Try again...");
         }
      } while (!validInput);  // repeat until input is valid
      
   }
   
   /** Update the "currentState" after the player with "theSeed" has placed on
       (currentRow, currentCol). */
   public static void updateGame(int theSeed, int currentRow, int currentCol) {
      if (hasWon(theSeed, currentRow, currentCol)) {  // check if winning move
         currentState = (theSeed == CROSS) ? CROSS_WON : NOUGHT_WON;
      } else if (isDraw()) {  // check for draw
         currentState = DRAW;
      }
      // Otherwise, no change to currentState (still PLAYING).
   }
   /** Return true if it is a draw (no more empty cell) */
   // TODO: Shall declare draw if no player can "possibly" win
   public static boolean isDraw() {
      for (int row = 0; row < ROWS; ++row) {
         for (int col = 0; col < COLS; ++col) {
            if (board[row][col] == EMPTY) {
               return false;  // an empty cell found, not draw, exit
            }
         }
      }
      return true;  // no empty cell, it's a draw
   } 
   /** Return true if the player with "theSeed" has won after placing at
       (currentRow, currentCol) */
   public static boolean hasWon(int theSeed, int currentRow, int currentCol) {
      return (board[currentRow][0] == theSeed         // 3-in-the-row
                   && board[currentRow][1] == theSeed
                   && board[currentRow][2] == theSeed
              || board[0][currentCol] == theSeed      // 3-in-the-column
                   && board[1][currentCol] == theSeed
                   && board[2][currentCol] == theSeed
              || currentRow == currentCol            // 3-in-the-diagonal
                   && board[0][0] == theSeed
                   && board[1][1] == theSeed
                   && board[2][2] == theSeed
              || currentRow + currentCol == 2  // 3-in-the-opposite-diagonal
                   && board[0][2] == theSeed
                   && board[1][1] == theSeed
                   && board[2][0] == theSeed);
   } 
   /** Print the game board */
   public static void printBoard() {
      for (int row = 0; row < ROWS; ++row) {
         for (int col = 0; col < COLS; ++col) {
            printCell(board[row][col]); // print each of the cells
            if (col != COLS - 1) {
               System.out.print("|");   // print vertical partition
            }
         }
         System.out.println();
         if (row != ROWS - 1) {
            System.out.println("-----------"); // print horizontal partition
         }
      }
      System.out.println();      
   } 
   /** Print a cell with the specified "content" */
   public static void printCell(int content) {
      switch (content) {
         case EMPTY:  System.out.print("   "); break;
         case NOUGHT: System.out.print(" O "); break;
         case CROSS:  System.out.print(" X "); break;
      }
   }
    public static void gameSave() {
       System.out.println("would you like to save the game? enter (1) to save the game or any other key to continue >>");
            choice=in.nextInt();
            if(choice==1)//saves the game
            {
                System.out.println("the game has been saved successfully");
                System.out.println("**********************************************************");
            }
            else{
                System.out.print("would you like to play again? enter "+EXIT+" to exit or any other key to play >>");
                char ans = in.next().charAt(0);
   if (ans == 'x' || ans == 'X') {
      System.out.println("Bye! THANK YOU FOR PLAYING");
      System.exit(0);  // terminate the program
   }
   else{
       System.out.print("enter (1) to play the game or (2) to view the game history >>");
        choice=in.nextInt();
        if(choice==1){
       initGame();
       playerMove(currentPlayer);
       updateGame(currentPlayer, currntRow, currentCol);
       printBoard();
   }
        else if(choice==2){
            history();
        }
} while (true);  // repeat until user did not answer yes               
            }
    }

    public static void playerInput() {
        System.out.print("Please enter player (X) name >>");
        player1=in.next();
        System.out.print("please enter player (O) name >>");
        player2=in.next();
        System.out.println();
         initGame();         
      
    do {
         playerMove(currentPlayer); // update currentRow and currentCol
         updateGame(currentPlayer, currntRow, currentCol); // update currentState
         printBoard();
         // Print message if game-over
    if (currentState == CROSS_WON) {
        System.out.println("congratulations! "+player1+" you won!");
        System.out.println("************************************************************");
            gameSave(); } 
    else if (currentState == NOUGHT_WON) {
        System.out.println("congratulations! "+player2+" you won!");
        System.out.println("************************************************************");
            gameSave(); } 
    else if (currentState == DRAW) {
        System.out.println("It's a Draw!");
        System.out.println("************************************************************"); 
            gameSave();
         }
         
         // Switch player
         currentPlayer = (currentPlayer == CROSS) ? NOUGHT : CROSS;
               } while (currentState == PLAYING); // repeat if not game-over 
    }

    public static void history() {
        Date date=new Date();
        System.out.println("**************************************************************");
        System.out.println("Player Name :"+player1);
        System.out.println(date.toString());
        System.out.println("**************************************************************");
        System.out.println("Player Name :"+player2);
        System.out.println(date.toString());
    }


            }
                
 
    
   
   
   


    


