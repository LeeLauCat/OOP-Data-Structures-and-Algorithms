/*Moeti TL
32232780
WaterSort Puzzle part 3*/


public class StackAsMyArrayList<E> 
{   
    MyArrayList<E> theStack;
    
    public StackAsMyArrayList()
    {  theStack = new MyArrayList<E>();       
    }
	
   // insert at end of array
    public void push(E newElement)
    {
        if (!theStack.checkSpace())
            throw new IndexOutOfBoundsException
                    ("Stack out of bounds");
        theStack.add(theStack.getSize(),newElement);
    }
	
	// remove end of array
    public E pop()
    {
        E temp = null;

        boolean isDone = false;
        if (theStack.getSize() > 0)
            temp=theStack.remove(theStack.getSize()-1);

        // temp will be null in special case of empty list
        return temp;
    }


    public E peek() //remove end of array
    {  
		E temp = null;
		if (theStack.getSize() > 0)
			temp=theStack.get(theStack.getSize()-1);
		return temp; // temp will be null in special case of empty list
    }
	
	public String toString()
	{
		return theStack.toString();
	}
	
	public int getStackSize() {
       return theStack.getSize();
    }
	
    public boolean checkStackUniform() {
       return theStack.checkUniform();
    }
   
   
}//end class



