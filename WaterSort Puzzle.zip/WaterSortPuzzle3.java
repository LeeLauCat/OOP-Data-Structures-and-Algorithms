/*Moeti TL
32232780
WaterSort Puzzle part 3*/

import java.util.Scanner;


public class WaterSortPuzzle3{

    static Character red= new Character('r');
    static Character yellow= new Character('y');
    static Character blue= new Character('b');
  
    static  StackAsMyArrayList[] bottle;

    static int n;// n will store the number of bottles

    
    static public void ShowAll()// this function is to print all the bottle ink
    {
        System.out.println();
        System.out.println("Printing all the bottles");
        for(int i=0;i<n;i++)
        {
            System.out.println("Bottle "+i+" : "+ bottle[i].toString());
            
        }
        System.out.println();
        System.out.println("is the puzzle Solved : "+solved(bottle));
}

     public static void main(String []args){

        Scanner sc = new Scanner(System.in);
        n=5;
        
        bottle=new StackAsMyArrayList[n];// making an array of obj of size n

        for(int i=1;i<=n;i++)
        { System.out.println("-----------------------------------------");
            System.out.println("filling bottle "+ i);
            System.out.println("-----------------------------------------");
            bottle[i-1]=new StackAsMyArrayList();
            char temp;
            int k=4;
            
            System.out.println("Bottle has 4 slots\n");
            while(k>0)
            {
                System.out.println("Color of water glass you want to add   r/y/b : ");
                temp = sc.next().charAt(0);


                //using switch
                switch(temp)
                { case 'r':
                    bottle[i-1].push(red);
                    break;
                    case 'y':
                        bottle[i-1].push(yellow);
                        break;
                    case 'b':
                        bottle[i-1].push(blue);
                        break;
                }

                //showing no of glass added
                System.out.println("no of slots added " + bottle[i-1].getStackSize());

                //Checking that bottle is uniform or not . if it is uniform then we show it as true else false
                System.out.println ("Checking that bottle is uniform or not :: " + bottle[i-1].checkStackUniform());
                //System.out.println(bottle[i-1].toString());
                System.out.println();

                k--;
            }

        }
        // function to print all the bottle color
        ShowAll();
    }
     public static boolean solved(StackAsMyArrayList bottles[]){
         for(int i=1;i<=n;i++){
             if((bottle[0].checkStackUniform()==true)&&(bottle[1].checkStackUniform()==true)&&(bottle[2].checkStackUniform()==true)&&(bottle[3].checkStackUniform()==true)&&(bottle[4].checkStackUniform()==true))
             
                 return true;
             
             else
                 
                 return false;
         }
         return false;
         
     }
}
