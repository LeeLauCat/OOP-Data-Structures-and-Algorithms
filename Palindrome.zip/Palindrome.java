



public class Palindrome {

   
    public static void main(String[] args) {
     MyLinkedList List = new MyLinkedList(1);
        List.next = new MyLinkedList(2);
        (List.next).next = new MyLinkedList(3);
        print(List);
        makePalindrome(List); //print palindrome
        print(List);
        
        MyLinkedList list1 = new MyLinkedList(8);
        list1.next = new MyLinkedList(9);
        (list1.next).next = new MyLinkedList(1);
        ((list1.next).next).next = new MyLinkedList(4);
        print(list1);
        makePalindrome(list1);
        print(list1);
     
    }

   public static void makePalindrome(MyLinkedList root){
        if(root == null){
            return;
        }
        MyLinkedList newnode = new MyLinkedList(root.data);
        makePalindrome(root.next);
        MyLinkedList tail = root;
        while(tail.next != null){
            tail = tail.next;
        }
        tail.next = newnode;
    }
   /*
    for display purposes*/
    public static void print(MyLinkedList root){
        MyLinkedList temp = root;
        System.out.print("Elements in Linked list: ");
        while(temp != null){
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println(" \n");
        
    }
    }
    

