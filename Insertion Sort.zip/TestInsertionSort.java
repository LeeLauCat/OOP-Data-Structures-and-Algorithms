
import javax.swing.*;
import java.util.ArrayList;


public class TestInsertionSort {    
    
    public static void main(String[] args) {
        
        
        ArrayList<Integer> unsortedArray = new ArrayList<>();
        
        unsortedArray.add(6);
        unsortedArray.add(2);
        unsortedArray.add(7);
        unsortedArray.add(5);
        unsortedArray.add(1);
        unsortedArray.add(3);
        unsortedArray.add(4);   
        MyArrayList is = new MyArrayList(unsortedArray);
        
         
        System.out.println("**********Initial Unsorted Array**********");
        for(int i:MyArrayList.getInputArray()){
            System.out.print(i+" ");
           
        }
        
        is.sortGivenArray();
        
        System.out.println("\n**********Final Sorted Array**********");
        for(int i:MyArrayList.getInputArray()){
            System.out.print(i+" ");
        }
        }
}